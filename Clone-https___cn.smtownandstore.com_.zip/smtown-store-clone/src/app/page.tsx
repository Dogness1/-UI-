import HeroCarousel from '@/components/home/HeroCarousel';
import FeaturedProducts from '@/components/home/FeaturedProducts';
import ArtistSection from '@/components/home/ArtistSection';
import NewAlbumSection from '@/components/home/NewAlbumSection';

export default function Home() {
  return (
    <div>
      <HeroCarousel />
      <FeaturedProducts />
      <ArtistSection />
      <NewAlbumSection />
    </div>
  );
}
