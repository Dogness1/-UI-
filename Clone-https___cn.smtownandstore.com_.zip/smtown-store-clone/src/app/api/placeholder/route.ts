import { NextRequest, NextResponse } from 'next/server';
import { generatePlaceholderImage } from '@/components/layout/ImagePlaceholder';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;

  const width = searchParams.get('width')
    ? parseInt(searchParams.get('width') || '800', 10)
    : 800;

  const height = searchParams.get('height')
    ? parseInt(searchParams.get('height') || '800', 10)
    : 800;

  const text = searchParams.get('text') || 'SMTOWN & STORE';
  const bgColor = searchParams.get('bgColor') || '#f8e8f0';
  const textColor = searchParams.get('textColor') || '#333333';

  const svgDataUrl = generatePlaceholderImage({
    width,
    height,
    text,
    bgColor,
    textColor,
  });

  // Extract the SVG content from data URL
  const base64Data = svgDataUrl.split(',')[1];
  const svgContent = Buffer.from(base64Data, 'base64').toString('utf-8');

  return new NextResponse(svgContent, {
    headers: {
      'Content-Type': 'image/svg+xml',
      'Cache-Control': 'public, max-age=86400',
    },
  });
}
