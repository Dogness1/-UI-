import { NextApiRequest, NextApiResponse } from 'next';

interface PlaceholderImageParams {
  width?: number;
  height?: number;
  text?: string;
  bgColor?: string;
  textColor?: string;
}

export function generatePlaceholderImage({
  width = 800,
  height = 800,
  text = 'Image Placeholder',
  bgColor = '#f8e8f0',
  textColor = '#333333'
}: PlaceholderImageParams = {}): string {
  // Create an SVG placeholder
  const svg = `
    <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
      <rect width="${width}" height="${height}" fill="${bgColor}" />
      <text
        x="50%"
        y="50%"
        font-family="Arial, sans-serif"
        font-size="${Math.min(width, height) / 20}px"
        fill="${textColor}"
        text-anchor="middle"
        dominant-baseline="middle"
      >
        ${text}
      </text>
    </svg>
  `;

  // Convert SVG to base64 for data URL
  const svgBase64 = Buffer.from(svg).toString('base64');
  return `data:image/svg+xml;base64,${svgBase64}`;
}

// This can be used in an API route
export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const { width, height, text, bgColor, textColor } = req.query;

  const svgDataUrl = generatePlaceholderImage({
    width: width ? parseInt(width as string, 10) : undefined,
    height: height ? parseInt(height as string, 10) : undefined,
    text: text as string || undefined,
    bgColor: bgColor as string || undefined,
    textColor: textColor as string || undefined,
  });

  res.setHeader('Content-Type', 'image/svg+xml');
  res.status(200).send(Buffer.from(svgDataUrl.split(',')[1], 'base64'));
}
