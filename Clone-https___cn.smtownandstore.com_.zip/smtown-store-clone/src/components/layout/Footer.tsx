import Link from 'next/link';

const Footer = () => {
  return (
    <footer className="bg-zinc-50 pt-12 pb-6">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold text-sm mb-4">ABOUT US</h3>
            <nav className="space-y-2">
              <Link href="/about" className="block text-sm text-zinc-600 hover:text-zinc-900">
                Company Introduction
              </Link>
              <Link href="/terms" className="block text-sm text-zinc-600 hover:text-zinc-900">
                Terms of Service
              </Link>
              <Link href="/privacy" className="block text-sm text-zinc-600 hover:text-zinc-900">
                Privacy Policy
              </Link>
              <Link href="/guide" className="block text-sm text-zinc-600 hover:text-zinc-900">
                User Guide
              </Link>
            </nav>
          </div>

          <div>
            <h3 className="font-bold text-sm mb-4">CUSTOMER CENTER</h3>
            <nav className="space-y-2">
              <Link href="/faq" className="block text-sm text-zinc-600 hover:text-zinc-900">
                FAQ
              </Link>
              <Link href="/qna" className="block text-sm text-zinc-600 hover:text-zinc-900">
                1:1 Inquiry
              </Link>
              <Link href="/notice" className="block text-sm text-zinc-600 hover:text-zinc-900">
                Notice
              </Link>
              <Link href="/returns" className="block text-sm text-zinc-600 hover:text-zinc-900">
                Returns & Exchange
              </Link>
            </nav>
          </div>

          <div>
            <h3 className="font-bold text-sm mb-4">DELIVERY</h3>
            <nav className="space-y-2">
              <Link href="/shipping" className="block text-sm text-zinc-600 hover:text-zinc-900">
                Shipping Information
              </Link>
              <Link href="/tracking" className="block text-sm text-zinc-600 hover:text-zinc-900">
                Order Tracking
              </Link>
            </nav>
          </div>

          <div>
            <h3 className="font-bold text-sm mb-4">FOLLOW US</h3>
            <div className="flex space-x-4">
              <Link href="https://instagram.com" className="text-zinc-600 hover:text-zinc-900">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
                </svg>
              </Link>
              <Link href="https://twitter.com" className="text-zinc-600 hover:text-zinc-900">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/>
                </svg>
              </Link>
              <Link href="https://facebook.com" className="text-zinc-600 hover:text-zinc-900">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
                </svg>
              </Link>
              <Link href="https://youtube.com" className="text-zinc-600 hover:text-zinc-900">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
                  <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/>
                  <path d="m10 15 5-3-5-3z"/>
                </svg>
              </Link>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-zinc-200">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-4 md:mb-0">
              <p className="text-xs text-zinc-500">
                SM Entertainment Co., Ltd. | Business Registration: 123-45-67890
              </p>
              <p className="text-xs text-zinc-500 mt-1">
                Address: 123 Entertainment Street, Seoul, South Korea
              </p>
              <p className="text-xs text-zinc-500 mt-1">
                Customer Service: +82 123-456-7890 | Email: support@smtownandstore.com
              </p>
            </div>
            <div>
              <div className="flex space-x-4">
                <Link href="/language/kor" className="text-xs text-zinc-500 hover:text-zinc-900">
                  KOR
                </Link>
                <Link href="/language/eng" className="text-xs text-zinc-500 hover:text-zinc-900">
                  ENG
                </Link>
                <Link href="/language/jpn" className="text-xs text-zinc-500 hover:text-zinc-900">
                  JPN
                </Link>
                <Link href="/language/chn" className="text-xs text-zinc-500 hover:text-zinc-900">
                  CHN
                </Link>
              </div>
            </div>
          </div>
          <p className="text-xs text-zinc-500 mt-6">
            © {new Date().getFullYear()} SMTOWN & STORE. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
