"use client";

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight } from "lucide-react";

// Sample featured products data
const products = [
  {
    id: 1,
    name: 'Red Velvet Party House Photocard Set',
    price: 15000,
    image: '/api/placeholder?width=400&height=400&text=Red%20Velvet%20Photocard%20Set&bgColor=%23ffdddd',
    link: '/product/detail?product_no=1001',
    isNew: true,
    isHot: true
  },
  {
    id: 2,
    name: 'SEULGI Acrylic Stand & Photocard Set',
    price: 18000,
    image: '/api/placeholder?width=400&height=400&text=SEULGI%20Acrylic%20Stand&bgColor=%23fce5cd',
    link: '/product/detail?product_no=1002',
    isNew: true,
    isHot: false
  },
  {
    id: 3,
    name: 'aespa Winter Diary Photocard Set',
    price: 14000,
    image: '/api/placeholder?width=400&height=400&text=aespa%20Photocard%20Set&bgColor=%23cfe2f3',
    link: '/product/detail?product_no=1003',
    isNew: true,
    isHot: false
  },
  {
    id: 4,
    name: 'SuperM Official Light Stick',
    price: 35000,
    image: '/api/placeholder?width=400&height=400&text=SuperM%20Light%20Stick&bgColor=%23d9d2e9',
    link: '/product/detail?product_no=1004',
    isNew: true,
    isHot: true
  },
  {
    id: 5,
    name: 'NCT DREAM Photobook Set',
    price: 25000,
    image: '/api/placeholder?width=400&height=400&text=NCT%20DREAM%20Photobook&bgColor=%23d9ead3',
    link: '/product/detail?product_no=1005',
    isNew: true,
    isHot: false
  }
];

// Helper function to format price
const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('ko-KR', {
    style: 'currency',
    currency: 'KRW',
    currencyDisplay: 'symbol',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(price);
};

const FeaturedProducts = () => {
  return (
    <section className="py-12 bg-white">
      <div className="container">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-zinc-900">New Items</h2>
          <Link
            href="/products/new"
            className="text-sm text-zinc-500 flex items-center hover:text-zinc-900 transition-colors"
          >
            View All <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {products.map((product) => (
            <Link href={product.link} key={product.id}>
              <Card className="overflow-hidden border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-0">
                  <div className="relative aspect-square">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      className="object-cover"
                    />
                    {/* Product badges */}
                    <div className="absolute top-2 left-2 flex flex-col gap-1">
                      {product.isNew && (
                        <span className="px-2 py-1 text-xs font-medium bg-pink-500 text-white rounded">NEW</span>
                      )}
                      {product.isHot && (
                        <span className="px-2 py-1 text-xs font-medium bg-blue-500 text-white rounded">HOT</span>
                      )}
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="text-sm font-medium text-zinc-900 line-clamp-2">{product.name}</h3>
                    <p className="mt-2 text-sm font-bold text-zinc-900">{formatPrice(product.price)}</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
