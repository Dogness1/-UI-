"use client";

import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent } from "@/components/ui/card";

// Sample album data
const featuredAlbum = {
  artist: "IRENE",
  title: "Like A Flower",
  description: "The 1st Mini Album",
  image: "/albums/irene-like-a-flower.jpg",
  link: "/product/list?cate_no=2705"
};

const otherAlbums = [
  {
    id: 1,
    artist: "SUPER JUNIOR",
    title: "The Renaissance",
    image: "/albums/super-junior-renaissance.jpg",
    link: "/product/detail?product_no=1201"
  },
  {
    id: 2,
    artist: "NCT DREAM",
    title: "DREAMSCAPE",
    image: "/albums/nct-dream-dreamscape.jpg",
    link: "/product/detail?product_no=1202"
  },
];

const NewAlbumSection = () => {
  return (
    <section className="py-12 bg-pink-50 relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute top-10 left-10 w-16 h-16 rounded-full bg-yellow-300 opacity-70"></div>
      <div className="absolute bottom-20 left-1/4 w-10 h-10 rounded-full bg-sky-300 opacity-70"></div>
      <div className="absolute top-1/3 right-1/4 w-8 h-8 rounded-full bg-red-300 opacity-70"></div>
      <div className="absolute bottom-10 right-10 w-20 h-20 rounded-full bg-blue-300 opacity-70"></div>
      <div className="absolute top-1/2 left-1/3 w-12 h-12 rounded-full bg-green-300 opacity-70"></div>

      <div className="container relative z-10">
        <h2 className="text-2xl font-bold text-center text-zinc-900 mb-12">New Album</h2>

        <div className="grid grid-cols-12 gap-6 items-center">
          {/* Other Albums - Left */}
          <div className="col-span-12 md:col-span-3">
            <Card className="overflow-hidden border-0 shadow-sm">
              <CardContent className="p-0">
                <Link href={otherAlbums[0].link}>
                  <div className="relative aspect-square">
                    <Image
                      src={otherAlbums[0].image}
                      alt={`${otherAlbums[0].artist} - ${otherAlbums[0].title}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Featured Album - Center */}
          <div className="col-span-12 md:col-span-6">
            <div className="text-center mb-6">
              <h3 className="text-sm text-zinc-600">{featuredAlbum.artist} The 1st Mini Album</h3>
              <h2 className="text-2xl font-bold text-zinc-900 mt-1">{featuredAlbum.title}</h2>
            </div>

            <Card className="overflow-hidden border-0 shadow-sm">
              <CardContent className="p-0">
                <Link href={featuredAlbum.link}>
                  <div className="relative aspect-square">
                    <Image
                      src={featuredAlbum.image}
                      alt={`${featuredAlbum.artist} - ${featuredAlbum.title}`}
                      fill
                      className="object-cover"
                      priority
                    />
                  </div>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Other Albums - Right */}
          <div className="col-span-12 md:col-span-3">
            <Card className="overflow-hidden border-0 shadow-sm">
              <CardContent className="p-0">
                <Link href={otherAlbums[1].link}>
                  <div className="relative aspect-square">
                    <Image
                      src={otherAlbums[1].image}
                      alt={`${otherAlbums[1].artist} - ${otherAlbums[1].title}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewAlbumSection;
