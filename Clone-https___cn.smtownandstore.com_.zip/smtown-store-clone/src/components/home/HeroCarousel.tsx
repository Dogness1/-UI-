"use client";

import { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import type { CarouselApi } from "@/components/ui/carousel";

// Sample hero carousel items
const carouselItems = [
  {
    id: 1,
    image: '/api/placeholder?width=1200&height=600&text=MINI%20FANLIGHT%20KEYRING&bgColor=%23f0c7d5',
    title: 'MINI FANLIGHT KEYRING',
    link: '/product/list?cate_no=2702',
    alt: 'SM Artist Mini Fanlight Keyring'
  },
  {
    id: 2,
    image: '/api/placeholder?width=1200&height=600&text=Red%20Velvet%20Party%20House&bgColor=%23ffdddd',
    title: 'Red Velvet\'s Party House',
    link: '/product/collection/HBD/2025_IRENE.html',
    alt: 'Red Velvet Party House'
  },
  {
    id: 3,
    image: '/api/placeholder?width=1200&height=600&text=SEULGI%20The%202nd%20Mini%20Album&bgColor=%23cfe2f3',
    title: 'SEULGI The 2nd Mini Album',
    link: '/product/list?cate_no=2673',
    alt: 'SEULGI Accidentally On Purpose Album'
  },
  {
    id: 4,
    image: '/api/placeholder?width=1200&height=600&text=MARK%20The%201st%20Album&bgColor=%23d9ead3',
    title: 'MARK The 1st Album',
    link: '/product/list?cate_no=2705',
    alt: 'MARK The Firstfruit Album'
  },
];

const HeroCarousel = () => {
  const [api, setApi] = useState<CarouselApi | null>(null);
  const [current, setCurrent] = useState(0);
  const [autoPlayInterval, setAutoPlayInterval] = useState<NodeJS.Timeout | null>(null);

  const updateCurrent = useCallback(() => {
    if (!api) return;
    setCurrent(api.selectedScrollSnap());
  }, [api]);

  // Handle dot click
  const handleDotClick = useCallback((index: number) => {
    if (!api) return;
    api.scrollTo(index);
  }, [api]);

  // Setup and cleanup effects
  useEffect(() => {
    if (!api) return;

    updateCurrent();
    api.on("select", updateCurrent);

    // Setup autoplay
    const interval = setInterval(() => {
      api.scrollNext();
    }, 5000);

    setAutoPlayInterval(interval);

    return () => {
      api.off("select", updateCurrent);
      if (autoPlayInterval) clearInterval(autoPlayInterval);
    };
    // Removed autoPlay from dependencies to prevent infinite render loop
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api, updateCurrent]);

  return (
    <div className="relative w-full">
      <Carousel
        setApi={setApi}
        className="h-[400px] md:h-[500px] lg:h-[600px] w-full"
        opts={{
          loop: true,
          align: 'start',
        }}
      >
        <CarouselContent>
          {carouselItems.map((item) => (
            <CarouselItem key={item.id} className="relative pl-0">
              <Link href={item.link}>
                <div className="relative h-[400px] md:h-[500px] lg:h-[600px] w-full">
                  <Image
                    src={item.image}
                    alt={item.alt}
                    fill
                    className="object-cover"
                    priority
                  />
                  <div className="absolute bottom-8 left-8 bg-white bg-opacity-80 px-6 py-3 rounded-md">
                    <h3 className="text-xl font-semibold text-zinc-900">{item.title}</h3>
                  </div>
                </div>
              </Link>
            </CarouselItem>
          ))}
        </CarouselContent>

        <CarouselPrevious className="absolute left-4 h-10 w-10" />
        <CarouselNext className="absolute right-4 h-10 w-10" />
      </Carousel>

      {/* Carousel Navigation Dots */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {carouselItems.map((_, index) => (
          <button
            key={index}
            className={`h-2 w-2 rounded-full transition-all ${
              current === index ? 'bg-white w-6' : 'bg-white/50'
            }`}
            onClick={() => handleDotClick(index)}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroCarousel;
