"use client";

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight } from "lucide-react";

// Sample featured artist data
const artists = [
  {
    name: 'BoA',
    image: '/artists/boa.jpg',
    link: '/product/celeb_boa?cate_no=45'
  },
  {
    name: 'TVXQ!',
    image: '/artists/tvxq.jpg',
    link: '/product/celeb_tvxq?cate_no=46'
  },
  {
    name: 'SUPER JUNIOR',
    image: '/artists/super-junior.jpg',
    link: '/product/celeb_superjunior?cate_no=47'
  },
  {
    name: 'GIRLS\' GENERATION',
    image: '/artists/girls-generation.jpg',
    link: '/product/celeb_girlsgeneration?cate_no=48'
  },
  {
    name: 'SHINee',
    image: '/artists/shinee.jpg',
    link: '/product/celeb_shinee?cate_no=49'
  },
  {
    name: 'EXO',
    image: '/artists/exo.jpg',
    link: '/product/celeb_exo?cate_no=51'
  },
  {
    name: 'Red Velvet',
    image: '/artists/red-velvet.jpg',
    link: '/product/celeb_redvelvet?cate_no=52'
  },
  {
    name: 'NCT',
    image: '/artists/nct.jpg',
    link: '/product/celeb_nct?cate_no=53'
  },
  {
    name: 'WayV',
    image: '/artists/wayv.jpg',
    link: '/product/celeb_wayv?cate_no=434'
  },
  {
    name: 'SuperM',
    image: '/artists/superm.jpg',
    link: '/product/celeb_superm?cate_no=665',
    featured: true
  },
  {
    name: 'aespa',
    image: '/artists/aespa.jpg',
    link: '/product/celeb_aespa?cate_no=1132'
  },
  {
    name: 'RIIZE',
    image: '/artists/riize.jpg',
    link: '/product/celeb_riize?cate_no=2003'
  },
  {
    name: 'Hearts2Hearts',
    image: '/artists/hearts2hearts.jpg',
    link: '/product/celeb_hearts2hearts?cate_no=2613'
  }
];

const ArtistSection = () => {
  // Get the artist with featured true for large feature
  const featuredArtist = artists.find(artist => artist.featured) || artists[0];

  // Display the rest of the artists in the regular grid
  const regularArtists = artists.filter(artist => artist !== featuredArtist);

  return (
    <section className="py-12 bg-zinc-50">
      <div className="container">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-zinc-900">Celeb for You</h2>
          <Link
            href="/celeb"
            className="text-sm text-zinc-500 flex items-center hover:text-zinc-900 transition-colors"
          >
            View All <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Top row with artists list */}
          <div className="col-span-12 mb-2 overflow-auto">
            <div className="flex space-x-6 min-w-max pb-2">
              {artists.map((artist) => (
                <Link
                  key={artist.name}
                  href={artist.link}
                  className="text-sm font-medium text-zinc-600 hover:text-zinc-900 whitespace-nowrap"
                >
                  {artist.name}
                </Link>
              ))}
            </div>
          </div>

          {/* Featured Artist */}
          <div className="col-span-12 md:col-span-3">
            <div className="bg-pink-100 rounded-full p-8 flex items-center justify-center max-w-xs mx-auto">
              <div className="text-center">
                <h3 className="text-xl font-semibold text-zinc-900 mb-2">{featuredArtist.name}</h3>
                <Link
                  href={featuredArtist.link}
                  className="text-sm text-zinc-600 flex items-center justify-center hover:text-zinc-900"
                >
                  View more <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </div>
            </div>
          </div>

          {/* Artist Featured Product */}
          <div className="col-span-12 md:col-span-9">
            <Card className="overflow-hidden border-0 h-full">
              <CardContent className="p-0 h-full">
                <div className="relative w-full h-full bg-white">
                  <Image
                    src="/products/featured-artist-product.jpg"
                    alt="Featured Artist Product"
                    width={500}
                    height={300}
                    className="object-contain"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ArtistSection;
